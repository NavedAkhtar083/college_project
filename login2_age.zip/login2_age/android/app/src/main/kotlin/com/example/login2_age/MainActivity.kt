package com.example.login2_age

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
